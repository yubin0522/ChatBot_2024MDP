# streamlit run test5.py
# 화면 구성 변화
import streamlit as st
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
import json

# 텍스트 처리에 사용되는 기존 코드
def generate_response(user_input, df, model):
    embedding = model.encode(user_input)
    df['distance'] = df['embedding'].map(lambda x: cosine_similarity([embedding], [x]).squeeze())
    answer = df.loc[df['distance'].idxmax()]
    return answer['챗봇']

def main():
    st.set_page_config(
        page_title="ChatBot",
        page_icon=":robot_face:"
    )

    st.title("인마고 :red[Q&A Chat] :robot_face:")

    # 데이터 및 모델 로드
    model = SentenceTransformer('jhgan/ko-sroberta-multitask')
    df = pd.read_csv('wellness_dataset.csv')
    df['embedding'] = df['embedding'].apply(json.loads)

    if "conversation" not in st.session_state:
        st.session_state.conversation = None

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    if "processComplete" not in st.session_state:
        st.session_state.processComplete = None

    # 사이드바는 제거되었습니다.

    if 'messages' not in st.session_state:
        st.session_state['messages'] = [{"role": "assistant", 
                                        "content": "안녕하세요! 인천전자마이스터고등학교에 대해 궁금하신 것이 있으면 언제든 물어봐주세요!"}]

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # 채팅 내용을 텍스트 파일로 저장
    if st.button('채팅 내용 저장'):
        with open('chat_history.txt', 'w', encoding='utf-8') as f:
            for content in st.session_state.chat_history:
                f.write(f"{content['role']}: {content['message']}\n")
        st.success('채팅 내용이 chat_history.txt 파일에 저장되었습니다.')

    # 챗봇 로직
    if query := st.chat_input("질문을 입력해주세요."):
        st.session_state.messages.append({"role": "user", "content": query})

        with st.chat_message("user"):
            st.markdown(query)

        with st.chat_message("assistant"):
            response = generate_response(query, df, model)

            st.markdown(response)
            # 필요한 경우 여기에 소스 문서 정보를 포함할 수 있습니다.

        # 챗봇 메시지를 채팅 기록에 추가합니다.
        st.session_state.messages.append({"role": "assistant", "content": response})
        # 채팅 내용을 텍스트 파일에 추가합니다.
        st.session_state.chat_history.append({"role": "user", "message": query})
        st.session_state.chat_history.append({"role": "assistant", "message": response})


if __name__ == '__main__':
    main()
