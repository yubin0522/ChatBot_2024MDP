#간단 모델 코드

import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import json
model = SentenceTransformer('jhgan/ko-sroberta-multitask')

# sentences = ["안녕하세요", "한국어 문장 임베딩 뭐시기 입니다"]

# embeddings = model.encode(sentences)

# print(embeddings)


df = pd.read_csv('wellness_dataset.csv')

df = df[~df['챗봇'].isna()]

df['embedding'] = pd.Series([[]] * len(df)) # dummy

df['embedding'] = df['유저'].map(lambda x: list(model.encode(x)))

df.to_csv('wellness_dataset.csv', index=False)

text = '요즘 머리가 아프고 너무 힘들어'

embedding = model.encode(text)

df['distance'] = df['embedding'].map(lambda x: cosine_similarity([embedding], [x]).squeeze())

answer = df.loc[df['distance'].idxmax()]

print('구분', answer['구분'])
print('유사한 질문', answer['유저'])
print('챗봇 답변', answer['챗봇'])
print('유사도', answer['distance'])
