from flask import Flask, render_template, redirect, url_for, jsonify, request
import serial
import threading
import time
import pandas as pd
import json
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# 시리얼 포트 설정
SERIAL_PORT = '/dev/ttyAMA0'
BAUD_RATE = 115200

# 전환할 페이지를 저장하는 변수와 상태 변경 플래그
current_page = 'main'
page_changed = False
floor = 'floor0'
# 시리얼 포트를 전역 변수로 사용
ser = None

def connect_serial():
    global ser
    while True:
        try:
            ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
            print(f"Connected to {SERIAL_PORT}")
            break
        except serial.SerialException as e:
            print(f"Failed to connect to serial port {SERIAL_PORT}: {e}")
            time.sleep(5)  # 5초 후 재시도

def reset_serial_connection():
    global ser
    ser.close()
    time.sleep(1)
    connect_serial()

# 시리얼 데이터를 읽고 페이지를 전환하는 함수
def read_serial():
    global current_page, page_changed, ser
    while True:
        try:
            if ser.in_waiting > 0:
                data = ser.readline().decode('utf-8').strip()
                print(f"Received data: {data}")
                if data == '1':
                    current_page = 'page1'
                    page_changed = True
                    print("Switching to page 1")
                elif data == '2':
                    current_page = 'page2'
                    page_changed = True
                    print("Switching to page 2")
                elif data == '3':
                    current_page = 'main'
                    page_changed = True
                    print("Switching to main page")
        except serial.SerialException as e:
            print(f"Serial exception: {e}")
            reset_serial_connection()
        except Exception as e:
            print(f"Unexpected error: {e}")

# 초기화 함수
def initialize():
    connect_serial()
    if ser:
        # 시리얼 읽기를 위한 스레드 시작
        serial_thread = threading.Thread(target=read_serial)
        serial_thread.daemon = True
        serial_thread.start()

# 초기화를 호출
initialize()

# 데이터 및 모델 로드
def load_model_and_data():
    model = SentenceTransformer('jhgan/ko-sroberta-multitask')
    df = pd.read_csv('wellness_dataset.csv')
    df['embedding'] = df['embedding'].apply(json.loads)
    return model, df

model, df = load_model_and_data()

# 챗봇 응답 생성 함수
def generate_response(user_input, df, model):
    embedding = model.encode(user_input)
    df['distance'] = df['embedding'].map(lambda x: cosine_similarity([embedding], [x]).squeeze())
    answer = df.loc[df['distance'].idxmax()]
    return answer['챗봇']

# 페이지 1 (챗봇) 렌더링 함수
@app.route('/page1', methods=['GET', 'POST'])
def page1():
    global page_changed
    user_input = None
    response = None
    messages = []
    
    if request.method == 'POST':
        if 'query' in request.form:
            user_input = request.form['query']
            response = generate_response(user_input, df, model)
            messages.append({'role': 'user', 'content': user_input})
            messages.append({'role': 'bot', 'content': response})
    else:
        messages.append({'role': 'bot', 'content': '인천전자마이스터고와 MDP에 대해 궁금한 점을 질문해주세요!'})  # 초기 메시지 추가

    return render_template('page1.html', user_input=user_input, response=response, messages=messages, page_changed=page_changed)

# 페이지 2 (맵) 렌더링 함수
@app.route('/page2', methods=['GET', 'POST'])
def page2():
    global current_page
    current_page = 'page2'
    return render_template('page2.html')

# 본관 정보 페이지
@app.route('/main_building', methods=['GET', 'POST'])
def main_building():
    global current_page
    current_page = 'main_building'
    if request.method == 'POST':
        floor = request.form.get('floor', '1')  # 기본값은 1층
    else:
        floor = '1'
    return render_template('main_building.html', floor=floor)

# 기숙사동 정보 페이지
@app.route('/dormitory', methods=['GET', 'POST'])
def dormitory():
    global current_page, floor
    current_page = 'dormitory'
    if request.method == 'POST':
        floor = request.form['floor']
    else:
        floor = 'floor0'
    return render_template('dormitory.html', floor=floor)

# MeiBot 설명 페이지
@app.route('/meibot_info')
def meibot_info():
    global current_page
    current_page = 'meibot_info'
    return render_template('meibot_info.html')

# 현재 페이지로 리다이렉트하는 라우트
@app.route('/current')
def current():
    global current_page, page_changed
    page_changed = False
    print(f"Redirecting to {current_page}")
    return redirect(url_for(current_page))

# 페이지 상태 엔드포인트
@app.route('/status')
def status():
    global page_changed
    return jsonify(page_changed=page_changed)

# 메인 페이지
@app.route('/')
def main():
    global current_page
    current_page = 'main'
    return render_template('main.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
