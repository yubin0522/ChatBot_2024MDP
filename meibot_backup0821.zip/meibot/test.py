import serial

# 시리얼 포트 설정 (포트 이름과 속도 설정)
ser = serial.Serial(
    port='/dev/ttyAMA0',  # 확인된 시리얼 포트로 변경
    baudrate=115200,        # STM32와 동일한 전송 속도 설정
    timeout=1             # 타임아웃 설정
)

try:
    while True:
        if ser.in_waiting > 0:  # 수신된 데이터가 있는지 확인
            data = ser.readline().decode('utf-8').rstrip()  # 데이터를 읽고 디코딩
            if data == '1':
                print("button1 pressed")
            elif data == '2':
                print("button2 pressed")
            elif data == '3':
                print("button3 pressed")
except KeyboardInterrupt:
    print("Program stopped by user")
finally:
    ser.close()  # 시리얼 포트를 닫음
